---
name: Clay & Coal
colors:
  surface: '#151311'
  surface-dim: '#151311'
  surface-bright: '#3b3936'
  surface-container-lowest: '#100e0c'
  surface-container-low: '#1d1b19'
  surface-container: '#211f1d'
  surface-container-high: '#2c2a27'
  surface-container-highest: '#373432'
  on-surface: '#e7e1de'
  on-surface-variant: '#dbc1b9'
  inverse-surface: '#e7e1de'
  inverse-on-surface: '#32302e'
  outline: '#a38c85'
  outline-variant: '#55433d'
  surface-tint: '#ffb59d'
  primary: '#ffb59d'
  on-primary: '#5d1901'
  primary-container: '#da7756'
  on-primary-container: '#541500'
  inverse-primary: '#994528'
  secondary: '#c9c6c2'
  on-secondary: '#31302d'
  secondary-container: '#474743'
  on-secondary-container: '#b7b5b0'
  tertiary: '#5ddac8'
  on-tertiary: '#003731'
  tertiary-container: '#00a494'
  on-tertiary-container: '#00312c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59d'
  on-primary-fixed: '#390b00'
  on-primary-fixed-variant: '#7b2f13'
  secondary-fixed: '#e5e2dd'
  secondary-fixed-dim: '#c9c6c2'
  on-secondary-fixed: '#1c1c19'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#7cf7e4'
  tertiary-fixed-dim: '#5ddac8'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005048'
  background: '#151311'
  on-background: '#e7e1de'
  surface-variant: '#373432'
  coal-bg: '#1F1D1B'
  coal-surface: '#141413'
  clay-accent: '#DA7756'
  cream-text: '#F5F2ED'
  warn-yellow: '#F3AE35'
  border-muted: '#2E2C29'
typography:
  headline-xl:
    fontFamily: Thmanyah Serif Display
    fontSize: 36px
    fontWeight: '900'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Thmanyah Serif Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Thmanyah Serif Display
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Thmanyah Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Thmanyah Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Thmanyah Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Thmanyah Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
  mono-code:
    fontFamily: monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is a sophisticated interpretation of a high-end CLI (Command Line Interface), blending the raw, tactile warmth of "Clay" with the industrial precision of "Coal." It is designed for users who appreciate the "Claude Code" aesthetic—minimalist, text-heavy, and focused on utilitarian elegance.

### Personality & Tone
- **Warm Industrial:** The interface moves away from the cold blues of typical tech products toward an earthy, grounded palette.
- **Precision-Focused:** Every element feels intentionally placed, echoing the efficiency of a terminal-based workflow.
- **Analog-Digital Hybrid:** The use of "Clay" as an accent color provides a organic contrast to the rigid "Coal" architecture, creating a premium, boutique software feel.

### Visual Style
The system adopts a **Minimalist-Tactile** movement. It avoids shadows entirely, relying on **Tonal Layering** and crisp 1px borders to define hierarchy. The aesthetic is flat but depth-rich, utilizing high-contrast typography and specific semantic color-coding to guide the eye through dense information.

## Colors

The "Clay & Coal" palette is a high-contrast, dark-first system designed for readability and focus.

- **Coal (#1F1D1B & #141413):** The foundation of the system. The darker surface (#141413) is used for the primary canvas, while the lighter coal (#1F1D1B) defines cards and interactive containers.
- **Clay (#DA7756):** The primary brand accent. Used sparingly for critical action points, active indicators, and high-priority states.
- **Cream (#F5F2ED):** The primary content color. It is softer on the eyes than pure white, maintaining a premium "paper-like" quality against the dark background.
- **Warn (#F3AE35):** A distinct amber-yellow used exclusively for semantic warnings to ensure clear visual separation from the terracotta-leaning Clay accent.
- **Muted Elements:** Metadata and inactive states use a desaturated version of the Cream text at 50-60% opacity.

## Typography

This design system retains the Thmanyah family, leveraging its unique character to balance tradition with modernity.

- **Serif Display:** Used for headers and branding to provide an authoritative, "editorial" look. It should be typeset with tight tracking.
- **Sans Interface:** Used for all functional UI elements. The weight should be slightly heavier (500-600) for labels to maintain the CLI aesthetic.
- **CLI Log/Code:** Use system monospaced fonts for technical logs and file paths. This ensures character alignment and reinforces the terminal aesthetic.
- **RTL Considerations:** The line-height is specifically tuned to prevent the clipping of Arabic diacritics while maintaining a compact, efficient vertical rhythm.

## Layout & Spacing

The layout is governed by a **Fixed-Width Utility** model, prioritizing density and logical grouping.

- **Grid:** A 12-column grid is used for desktop layouts, while mobile layouts collapse into a single-column stack.
- **CLI Rhythm:** Spacing is tight and controlled. Use 8px (2 units) for related elements and 24px (6 units) to separate major sections.
- **Reflow Rules:** In RTL mode, all components mirror. Ensure that progress indicators and icons (e.g., chevrons, arrows) are correctly flipped to maintain the directional logic of the interface.

## Elevation & Depth

This design system eschews shadows in favor of a "Physical Terminal" approach.

- **Tonal Layers:**
    - **Base:** Coal-Surface (#141413) serves as the primary canvas.
    - **Surface:** Coal-BG (#1F1D1B) is used for cards and floating panels.
    - **Inlay:** A slightly darker tint is used for input fields and log areas to suggest they are "recessed" into the UI.
- **Borders:** High-definition 1px borders using `border-muted` (#2E2C29) are the primary way to define container boundaries.
- **Accent Strokes:** Active elements (focused inputs, selected modes) receive a 1px solid border of `clay-accent` (#DA7756).

## Shapes

The shape language is **Soft-Technical**.

- **Primary Radius:** A 4px (0.25rem) radius is applied to almost all elements (buttons, inputs, cards). This provides just enough softness to feel modern without losing the "hard" terminal edge.
- **Status Pills:** Small chips and status indicators use a full pill shape to distinguish them from structural containers and interactive buttons.

## Components

### Buttons
- **Primary:** Background `clay-accent`, text `coal-surface`. Bold, high contrast. No shadow.
- **Secondary:** Transparent background, 1px border of `cream-text` (at 40% opacity). Text `cream-text`.
- **Tertiary/Ghost:** No border, text `cream-text` at 60% opacity, lightening to 100% on hover.

### Cards & Containers
- Cards use `coal-bg` with a 1px `border-muted`. Headers inside cards should have a thin divider separating them from the body content.

### Inputs & Terminal Fields
- **Fields:** Recessed background (darker than coal-surface), 1px border. On focus, the border changes to `clay-accent`.
- **Log View:** A dedicated area using `mono-code` font. Background should be the darkest tone in the system to simulate a terminal window.

### Status Indicators
- **Warn:** Yellow (#F3AE35) text with a 10% opacity yellow background tint.
- **Error:** Deep red text with a 10% opacity background tint.
- **Success:** Clay (#DA7756) can be used for success, or a dedicated muted green if Clay is too prominent for minor successes.

### Progress Bars
- **Track:** `border-muted` background.
- **Indicator:** `clay-accent` solid fill. For completed states, the indicator remains Clay to signify "Brand Done."